package com.replay.poc.service;

import java.util.List;

import com.replay.poc.model.ReplayValue;

public interface CustomerService {

	public List<ReplayValue> getPayloadRecords();
}
