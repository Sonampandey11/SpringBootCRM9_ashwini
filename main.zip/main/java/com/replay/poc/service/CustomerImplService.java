package com.replay.poc.service;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;
import com.replay.poc.mapper.Customer;
import com.replay.poc.model.ReplayValue;
import com.replay.poc.repository.CustRepository;
import com.replay.poc.repository.ReplayRepository;

@Service
public class CustomerImplService implements CustomerService {

	@Autowired
	CustRepository custRepository;

	@Autowired
	ReplayRepository replayRepository;

	@Autowired
	JmsTemplate jmsTemplate;

	public Customer getCustomerObject(int id) {
		return custRepository.findById(id).get();
	}

	public void sendToQueue1(String topic, Customer cust) {
		jmsTemplate.convertAndSend("PocReplaytopic1", cust, message -> {
			return message;
		});
	}

	public void sendToQueue2(String topic, Customer cust) {
		jmsTemplate.convertAndSend("PocReplaytopic2", cust, message -> {
			return message;
		});
	}

	public void sendToQueue3(String topic, Customer cust) {
		jmsTemplate.convertAndSend("PocReplaytopic3", cust, message -> {
			return message;
		});
	}

	public void sendToQueue4(String topic, Customer cust) {
		jmsTemplate.convertAndSend("PocReplaytopic4", cust, message -> {
			return message;
		});
	}

	@Override
	@Transactional
	public List<ReplayValue> getPayloadRecords() {
		List<ReplayValue> RList = replayRepository.getErrorLog();
		return RList;
	}
}
