package com.replay.poc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.replay.poc.model.Replay;
import com.replay.poc.model.ReplayValue;

public interface ReplayRepository extends JpaRepository<Replay, Integer> {

	@Query("select new com.replay.poc.model.ReplayValue(id,payload,queue,replay_queue) FROM Replay")
	public List<ReplayValue> getErrorLog();
}
