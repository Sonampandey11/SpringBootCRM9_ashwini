package com.replay.poc.controller;

import java.io.IOException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.replay.poc.mapper.Customer;
import com.replay.poc.model.ReplayValue;
import com.replay.poc.service.CustomerImplService;

@Controller
public class ReplayController {

	@Autowired
	CustomerImplService customerImplService;

	@Autowired
	ObjectMapper mapper;

	@RequestMapping("/view")
	public String view(ModelMap model) {
		List<ReplayValue> RList = customerImplService.getPayloadRecords();
		model.put("payloadRecords", RList);
		return "ViewReplayPayload";
	}

	@RequestMapping(value = "/send", method = RequestMethod.POST)
	public void playReplayQueue(List<ReplayValue> RList) {
		String queue = RList.get(0).getQueue();
		Object cust = RList.get(0).getPayload();
		Customer cu = (Customer) cust;
		customerImplService.sendToQueue1(queue, cu);
	}

	@RequestMapping("/send")
	public String showFormForUpdate(@RequestParam("payload") String thePayload, @RequestParam("queue") String theQueue,
			@RequestParam("replay_queue") String theReplayQueue, Model theModel)
			throws JsonMappingException, IOException {

		String queue1 = "queue1";
		String queue2 = "queue2";
		String queue3 = "queue3";
		String queue4 = "queue4";

		theModel.addAttribute("payload", thePayload);
		theModel.addAttribute("queue", theQueue);
		theModel.addAttribute("replayQueue", theReplayQueue);

		Customer customer = mapper.readValue(thePayload, Customer.class);

		if (theQueue.equalsIgnoreCase(queue1) && theReplayQueue.equalsIgnoreCase("N")) {
			customerImplService.sendToQueue1("PocReplaytopic1", customer);
		} else if (theQueue.equalsIgnoreCase(queue2) && theReplayQueue.equalsIgnoreCase("N")) {
			customerImplService.sendToQueue2("PocReplaytopic2", customer);
		} else if (theQueue.equalsIgnoreCase(queue3) && theReplayQueue.equalsIgnoreCase("N")) {
			customerImplService.sendToQueue3("PocReplaytopic3", customer);
		} else if (theQueue.equalsIgnoreCase(queue4) && theReplayQueue.equalsIgnoreCase("N")) {
			customerImplService.sendToQueue4("PocReplaytopic4", customer);
		}
		return "customer-form";
	}
}