package com.replay.poc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.replay.poc.mapper.Customer;
import com.replay.poc.mapper.CustomerMapper;
import com.replay.poc.mapper.NewCustomer;
import com.replay.poc.model.Replay;
import com.replay.poc.repository.ReplayRepository;
import com.replay.poc.service.CustomerImplService;

@RestController
@RequestMapping(value = "/api")
public class CustomersController {

	@Autowired
	CustomerImplService customerImplService;

	@Autowired
	CustomerMapper customerMapper;

	@Autowired
	ReplayRepository replayRepository;
	
	@Autowired
	ObjectMapper mapper;

	@PostMapping(value = "/cust/hhh")
	public NewCustomer fetchCustomer(@RequestBody Customer cust) throws JsonProcessingException {
		int id = cust.getId();
		Customer custom = customerImplService.getCustomerObject(id);

		
		if (custom.getAddress() == null) {
			Replay re = new Replay();
			String jsonInString = mapper.writeValueAsString(cust);
			re.setPayload(jsonInString);
			re.setId(id);
			re.setQueue("queue2"); //ReplayQueue1
			re.setReplay_queue("N");
			replayRepository.save(re);
		}

		/*customerImplService.sendToQueue1("Poc_topic1", cust);//BusinessQueue1
		NewCustomer newcust = customerMapper.customerMapping(cust);
		return createNewCustomer(newcust);*/
		
		NewCustomer newcust = customerMapper.customerMapping(cust);
		return createNewCustomer(newcust);
	}
	
	private NewCustomer createNewCustomer(NewCustomer newcust) {
		final String uri = "http://localhost:8085/api/rest/de_DE/adc-customerapi/newCustomer";
		RestTemplate restTemplate = new RestTemplate();
		NewCustomer result = restTemplate.postForObject(uri, newcust, NewCustomer.class);
		return result;
	}

	/*private NewCustomer createNewCustomer(NewCustomer newcust) {
		final String uri = "http://localhost:8085/api/rest/de_DE/adc-customerapi/newCustomer";
		RestTemplate restTemplate = new RestTemplate();
		NewCustomer result = restTemplate.postForObject(uri, newcust, NewCustomer.class);
		return result;
	}*/
}
