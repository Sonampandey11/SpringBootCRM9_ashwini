package com.replay.poc;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CRMMainApp {

	public static void main(String[] args) {
		
		SpringApplication.run(CRMMainApp.class, args);

	}

}
