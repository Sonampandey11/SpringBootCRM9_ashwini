package com.replay.poc.mapper;

import org.springframework.stereotype.Component;
@Component
public class CustomerMapper {

	public NewCustomer customerMapping(Customer cust) {
		
		NewCustomer newCust = new NewCustomer();

		/*if(cust.getId()) {
			
		}*/
		newCust.setNewId(cust.getId());
		newCust.setNewName(cust.getName());
		newCust.setNewAddress(cust.getAddress());
		newCust.setNewPhone(cust.getPhone());
		return newCust;
	}
}
