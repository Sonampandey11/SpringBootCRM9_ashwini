package com.capgemini.training.service;

import org.springframework.stereotype.Service;

@Service
public class AccountService {
	
	
/*	public String createAccount(Account account)
	{
		Account accnt=new Account();
		accnt.setAccountSource(account.getAccountSource());
		accnt.setADC_Business_Customer_Reference__c(account.getADC_Business_Customer_Reference__c());
      accnt.setADC_Account_ID_18__c(account.getADC_Account_ID_18__c());
		return accnt.getADC_Account_ID_18__c();
	}*/

}
